export class Customer {
	key: string;
	name: string;
	age: number;
	active = true;
}
