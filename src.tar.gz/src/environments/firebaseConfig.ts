

export const firebaseConfig = {
    // Paste all this from the Firebase console...
    apiKey: "AIzaSyCUFIogC3PKH1CwauBpTmE3cc7-0mJbBKI",
    authDomain: "bumerangu-29bb9.firebaseapp.com",
    databaseURL: "https://bumerangu-29bb9.firebaseio.com",
    storageBucket: "bumerangu-29bb9.appspot.com",
    messagingSenderId: "1060617568411"
};

